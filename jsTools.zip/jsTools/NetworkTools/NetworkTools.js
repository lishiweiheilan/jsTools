// var requestHandler = {
//   params: {},
//   success: function (res) {
//     // success
//   },
//   fail: function () {
//     // fail
//   },
// }
// // var params = {}

// function postRequest (api, params, success, fail, complete){
//   var date = Date.parse(new Date()).toString();
//   date = date.substr(0, 10);
//   // var params = params
//   var paramsStr = JSON.stringify(params);
//   var url = getApp().baseURL
//   var data = {
//     "api": api,
//     "params": paramsStr,
//     "level": "1",
//     "type": "1",
//     "time": date,
//     "ciphertext": "",
//   }
//   console.log('网络请求信息url=', url, 'params=', params, 'success=', success)
//   wx.request({
//     url: url,
//     data: data,
//     method: 'POST',
//     header: { 'content-type': 'application/x-www-form-urlencoded' },
//     success: function (res) {
//       requestHandler.success(res)
//     },
//     fail: function (res) {
//       requestHandler.fail(res)
//     },
//     complete: function (res) {

//     },
//   })
// }




// module.exports = {
//   postRequest: postRequest
// }

var requestHandler = {
  api:'',
  data:{},
  success: function (res) {
    // success
  },
  fail: function () {
    // fail
  },
}

//GET请求
function GET(requestHandler) {
  request('GET', requestHandler)
}
//POST请求
function POST( requestHandler) {
  
  request('POST', requestHandler)
}

function request(method,requestHandler) {
  //注意：可以对params加密等处理
  var date = Date.parse(new Date()).toString();
  date = date.substr(0, 10);
  // var params = params
  var paramsStr = JSON.stringify(requestHandler.data);
  var url = getApp().baseURL
  var data = {
    "api": requestHandler.api,
    "params": paramsStr,
    "level": "1",
    "type": "1",
    "time": date,
    "ciphertext": "",
  }
  console.log('-----请求数据-------', data)
  wx.request({
    url: url,
    data: data,
    method: method,
    header: { 'content-type': 'application/x-www-form-urlencoded' },
    success: function (res) {
      requestHandler.success(res)
    },
    fail: function (res) {
      requestHandler.fail(res)
    },
    complete: function (res) {

    },
  })
}

module.exports = {
  GET: GET,
  POST: POST
}
